from django import forms

class Query(forms.Form):
	Query=forms.CharField()